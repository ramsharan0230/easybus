<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubDestination extends Model
{
    protected $fillable=['busroutine_id','sub_destination','sub_price'];
}
