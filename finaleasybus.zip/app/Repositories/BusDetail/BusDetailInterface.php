<?php
namespace APp\Repositories\BusDetail;
use App\Repositories\Crud\CrudInterface;
interface BusDetailInterface extends CrudInterface{
	
}