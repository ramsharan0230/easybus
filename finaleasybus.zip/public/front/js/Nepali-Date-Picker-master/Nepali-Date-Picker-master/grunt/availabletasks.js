module.exports = {
    tasks: {
        options: {
            filter: 'exclude',
            tasks: ['availabletasks', 'tasks']
        }
    }
};
