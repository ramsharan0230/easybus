module.exports = {
    custom: {
        files: {
            'dist/nepaliDatePicker.min.css': [
                'src/nepaliDatePicker.css'
            ]
        }
    }
};
