module.exports = {
  customJs: {
      options: {},
      src: ['src/*.js']
  }
};
