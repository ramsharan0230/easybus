module.exports = {
    staticMappings: {
        files: [
            {src: 'src/jquery.nepaliDatePicker.js', dest: 'dist/jquery.nepaliDatePicker.min.js'}
        ],
        options: {
            report: 'min',
            mangle: false
        }
    }
};
