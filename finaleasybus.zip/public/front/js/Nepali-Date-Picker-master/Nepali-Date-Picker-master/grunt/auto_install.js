module.exports = {
    install: {
        options: {
            cwd: '',  //current dir
            stderr: true,
            failOnError: false,
            npm: true,
            bower: true
        }
    }
};
