<?php
	$value=session()->get('jointable');
	dd($value);
?>