<?php

return [
    /*
     * Edit following values for this package to work*/
    'merchant_code' => 'EASYBUS',      //Your merchant code should be inserted here.
    'apiuser' => 'easybus',            //API username provided by IMEPay.
    'password' => 'easybus123',           //Password provided by IMEPay.
    'module' => 'EASYBUS',             //Module provided by IMEPay.
];