
<?php $__env->startSection('title','Add SMS Notice'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>Add SMS Notice<small>EASYBUS</small></h1>
                <ol class="breadcrumb">
                    <li><a href="./"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">Routine</a></li>
                    <li class="active">Add SMS Routine</li>
                </ol>
            </section>
            
            <!-- Main content -->
            <section class="content">
                <div class="row equal_height">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-6">
                        <!-- Default box -->
                        <div class="box">
                            <?php if(Session::has('message')): ?>
                            <div class="alert alert-success alert-dismissible message">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <?php echo Session::get('message'); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger message">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <div class="box-body ">
                                <form action="<?php echo e(route('saveSms')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($detail->id); ?>">
								<div class="form-group">
									<label>SMS Notice</label>
									<textarea name="sms" class="form-control" rows="3"><?php echo e($detail->sms); ?></textarea>
								</div>
                                <div class="form-group">
                                    <input type="submit" name="submit" value="submit" class="btn btn-success">
                                    
                                </div>
                              	</form>
                                <a href="<?php echo e(route('sendSms',$detail->id)); ?>" class="btn btn-info">Send</a>
                            </div>
                        </div>  
                    </div>
                        <!-- /.box -->
                    </div>
                </div>
            </section>
            <!-- /.content -->
        
       

        	
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="//cdn.ckeditor.com/4.5.7/full/ckeditor.js"></script>

<script type="text/javascript">
    

</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(".bod-picker").val();
		$(".bod-picker").nepaliDatePicker({
		    dateFormat: "%y-%m-%d",
		    closeOnDateSelect: true,
		    // minDate: formatedNepaliDate
		});
	});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>