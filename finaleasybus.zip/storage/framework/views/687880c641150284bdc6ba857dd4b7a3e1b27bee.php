
<?php $__env->startSection('content'); ?>
<section class="">
	<div class="container user_dash">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 ">
				<div class="height_manage user-dash-page box_shadow">
					<div class="row">
					  	<div class="col-lg-2 col-sm-12">
						    <?php echo $__env->make('front.include.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					  	</div>
					  	<div class="col-lg-10 col-sm-12 text-capitalize">
							<div class="padding-manager">
								<div class="row">
									
									<div class="col-lg-12   col-sm-12 ">
										<table class="table table-bordered  text-uppercase font_13" width="100%">
											<thead>
												<tr>
													<th>ticket No.</th>
													<!-- <th>sit no</th>
													<th> Destination</th>
													<th>booked on</th>
													<th>departure date</th>
													<th>rate</th> -->
													
												</tr>
											</thead>
											<tbody>
												<?php $__currentLoopData = $booking_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr class='clickable-row' data-href='https://www.facebook.com/'>
													
													<td><?php echo e($data->book_no); ?></td>
													<td> <?php echo e($data->seat->seat_name); ?></td>
													<td>
														<small>
															from: <?php echo e($data->from); ?>

														</small>
														<br>
														<?php if($data->sub_destination): ?>
															<small>to: <?php echo e($data->sub_destination); ?></small>
														<?php else: ?>
															<small>to: <?php echo e($data->to); ?></small>
														<?php endif; ?>
														
													</td>
													<td><?php echo e($data->booked_on); ?></td>
													<td>
														<?php echo e($data->date); ?> <br>
														
													</td>
													<td>
														<span>Rs.</span> <?php echo e($data->price); ?> /-
													</td>
															
												</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
					  	</div>
					</div>
				</div>
			</div>
			 
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>