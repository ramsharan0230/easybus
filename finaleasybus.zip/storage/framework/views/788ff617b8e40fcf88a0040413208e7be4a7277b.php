
<?php $__env->startSection('title','Edit Assistant'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>Edit Assestant<small>EASYBUS</small></h1>
                <ol class="breadcrumb">
                    <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">Vendor</a></li>
                    <li><a href="#">Assistant</a></li>
                    <li class="active">Edit Assistant</li>
                </ol>
            </section>
            
            <!-- Main content -->
            <section class="content">
                <!-- <div class="row equal_height">
                    <div class="col-lg-12 col-sm-12 col-xs-12">
                        <div class="box">
                            <div class="box-header">
                                <a href="#" class="btn btn-success">All Vendor</a>
                            </div>
                        </div>
                    </div>
                </div> -->

                <div class="row equal_height ">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-6">
                        <!-- Default box -->
                        <div class="box">
                            <div class="box-header with-border">
                        <h3 class="box-title">Edit Assistant</h3>

                        <div class="box-tools pull-right">
                            <a href="<?php echo e(route('allAssistant')); ?>" class="btn btn-success">All Assestant</a>
                        </div>
                    </div>

                            <div class="box-body ">
                                <form action="<?php echo e(route('updateAssistant',$data->id)); ?>" class="form form-horizontal form-responsive" method="post" enctype="multipart/form-data">
                                	<?php echo e(csrf_field()); ?>

                                    <div class="row equal_height all-table-manage form-group">
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">  
                                            <input type="text" name="name" id="full_name" class="form-control" placeholder="Assestant Full Name" value="<?php echo e($data->name); ?>">
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <!-- <i class="fa fa-phone"></i> -->
                                                    Phone
                                                </div>
                                                <input type="text" name="phone" id="phone" class="form-control" data-inputmask='"mask": "(999) 999-9999"' data-mask='"mask": "(999) 999-9999"'  placeholder="Contact No" value="<?php echo e($data->phone); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <!-- <i class="fa fa-street-view"></i> -->
                                                    Address
                                                </div>
                                                <input type="text" name="address" id="address" class="form-control" placeholder="Address" value="<?php echo e($data->address); ?>">
                                            </div>
                                        </div>

                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    Email
                                                </div>
                                                <input type="email" name="email" id="email" class="form-control" placeholder="Email Address" value="<?php echo e($data->email); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    Category
                                                </div>
                                                <select name="category" class="form-control">
                                                    <option value="driver" <?php echo e($data->category=='driver'?'selected':''); ?>>Driver</option>
                                                    <option value="conductor" <?php echo e($data->category=='conductor'?'selected':''); ?>>Conductor</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    Passport Size Photo
                                                </div>
                                                <input type="file" name="passport_image" id="image" class="form-control" placeholder="Profile Image">
                                               
                                            </div>
                                             <?php if($data->passport_image): ?>
                                               <div class="form-group">
                                                  <strong>Thumbnail Image</strong>
                                                  <br>
                                                  <img src="<?php echo e(asset('images/document/'.$data->passport_image)); ?>" />
                                               </div>
                                               <?php endif; ?>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    Front copy of Citizenship
                                                </div>
                                                <input type="file" name="citizen_front" id="image" class="form-control" placeholder="Citizenship Front Image">
                                            </div>
                                            <?php if($data->citizen_front): ?>
                                               <div class="form-group">
                                                  <strong>Thumbnail Image</strong>
                                                  <br>
                                                  <img src="<?php echo e(asset('images/document/'.$data->citizen_front)); ?>" />
                                               </div>
                                               <?php endif; ?>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    Back copy of Citizenship
                                                </div>
                                                <input type="file" name="citizen_back" id="image" class="form-control" placeholder="Citizenship Back Image">
                                            </div>
                                            <?php if($data->citizen_back): ?>
                                               <div class="form-group">
                                                  <strong>Thumbnail Image</strong>
                                                  <br>
                                                  <img src="<?php echo e(asset('images/document/'.$data->citizen_back)); ?>" />
                                               </div>
                                               <?php endif; ?>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    Front copy of Driving License
                                                </div>
                                                <input type="file" name="driving_front" id="image" class="form-control" placeholder="Driving License Front Image">
                                            </div>
                                            <?php if($data->driving_front): ?>
                                               <div class="form-group">
                                                  <strong>Thumbnail Image</strong>
                                                  <br>
                                                  <img src="<?php echo e(asset('images/document/'.$data->driving_front)); ?>" />
                                               </div>
                                               <?php endif; ?>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    Back copy of Driving License
                                                </div>
                                                <input type="file" name="driving_back" id="image" class="form-control" placeholder="Driving License Front Image">
                                            </div>
                                            <?php if($data->driving_back): ?>
                                               <div class="form-group">
                                                  <strong>Thumbnail Image</strong>
                                                  <br>
                                                  <img src="<?php echo e(asset('images/document/'.$data->driving_back)); ?>" />
                                               </div>
                                               <?php endif; ?>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <!-- <i class="fa fa-key"></i> -->
                                                    Password
                                                </div>
                                                <input type="password" id="password" name="password" class="form-control" placeholder="Password">
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <!-- <i class="fa fa-key"></i> -->
                                                    Re-type Password
                                                </div>
                                                <input type="password" class="form-control" id="re_password" name="password_confirmation" placeholder="Password">
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 m_b20">
                                            <div class="box-tools pull-right">
                                                <div class="input-group">
                                                    <button type="reset" class="btn btn-info"> <span class="fa fa-trash"></span> Cancel</button>

                                                    <button type="submit" class="btn btn-success"> <span class="fa fa-send"></span> submit</button>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>   
                    </div>
                </div>
            </section>
            <!-- /.content -->
        
       

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>