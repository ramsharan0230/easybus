<?php $__env->startSection('title','All History'); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>Counter's All Bookings<small>EASYBUS</small></h1>
                <ol class="breadcrumb">
                    <li><a href="./"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">Counter</a></li>
                    <li class="active">Counter's All Bookings</li>
                </ol>
            </section>
            
            <!-- Main content -->
            <section class="content">
                <div class="row equal_height">
                    <div class="col-lg-12">
                        <!-- Default box -->
                        <div class="box">

                            <!-- <div class="box-header">
                                <a href="add-destination.php" class="btn btn-success">Add New Passengers</a>
                            </div> -->
                            <div class="box-body vendor-box">
                                <table id="datatable" class="table vendor-table responsive table-hover dt-responsive nowrap bulk_action" >
                                    
                                    <thead class="vendor-head">
                                        <tr>
                                            <th>Sn</th>
                                            <th>Seat No.:</th>
                                            <th>
                                                <span class="fa fa-user"></span> Passenger Name & No.
                                            </th>
                                            <th>
                                                <i class="fa fa-calendar"></i> Bus No.:
                                            </th>
                                            <th>
                                                <i class="fa fa-calendar"></i> Date:
                                            </th>
                                            <!-- <th>
                                                <span class="fa fa-user"></span>Departure Detail  
                                            </th> -->
                                            <!-- <th>Pickup Station</th> -->
                                            <th> 
                                                <i class="fa fa-street-view"></i> Passenger Station
                                            </th>
                                            <!-- <th> 
                                                <i class="fa fa-user-circle"></i> Assestant 1
                                            </th>
                                            <th> 
                                                <i class="fa fa-user-circle"></i> Assestant 2
                                            </th> -->
                                        </tr>
                                    </thead>
                                    <tbody class="text-uppercase">
                                        <?php ($i=1); ?>
                                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <tr >
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($booking->seat->seat_name); ?></td>
                                            <td><?php echo e($booking->name); ?> <br> 
                                                <small><?php echo e($booking->phone); ?></small></td>
                                            <td><?php echo e($booking->bus->bus_number); ?></td>
                                            <!-- <td> 2075-12-12 <br>
                                                <small>12:55:00 PM</small>
                                            </td> -->
                                            <td><?php echo e($booking->date); ?></td>
                                            <td>
                                                From: <?php echo e($booking->pickup_station); ?> <br> To: <?php echo e($booking->drop_station); ?>

                                            </td>
                                           
                                            <!-- <td>
                                                <?php if($booking->bus->driver): ?>
                                                <?php echo e($booking->bus->driver->name); ?> <br>
                                                <small><?php echo e($booking->bus->assistant_one_phone); ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($booking->bus->conductor): ?>
                                                <?php echo e($booking->bus->conductor->name); ?> <br>
                                                <small><?php echo e($booking->bus->assistant_two_phone); ?></small>
                                                <?php endif; ?>
                                            </td> -->
                                            
                                            <!-- <td>
                                                <a href="add-bus.php" class="btn btn-info"> <span class="fa fa-edit"></span> Edit</a>
                                                <div class="btn  btn-danger">
                                                    <form method= "post" action="" class="delete">
                                                        <input type="hidden" name="_method" value="DELETE">
                                                        <button type="submit" class="btn-delete" style="display:inline"><span class="fa fa-trash"></span> Delete</button>
                                                    </form>
                                                </div>
                                            </td> -->
                                        </tr>
                                        <?php ($i++); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                        
                                        
                                    </tbody>
                                </table> 
                            </div>  
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </section>
            <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    $(function () {
        $("#datatable").DataTable();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>