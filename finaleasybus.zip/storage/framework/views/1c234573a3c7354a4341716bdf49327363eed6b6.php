<?php $__env->startSection('title','Bus Routine'); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>Bus Routine(<?php echo e($bus->bus_name); ?>)<small>List</small></h1>
	<a href="<?php echo e(route('addRoutine',$bus->id)); ?>" class="btn btn-success">Add Routine</a>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"></i>Dashboard</a></li>
		<li><a href="">Bus Routine</a></li>
		<li><a href="">list</a></li>
	</ol>
</section>
<div class="content">
	<?php if(Session::has('message')): ?>
	<div class="alert alert-success alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
      		<span aria-hidden="true">&times;</span>
    	</button>
    	<?php echo Session::get('message'); ?>

	</div>
	<?php endif; ?>
	
	<div class="row">
		<div class="col-xs-12">
			<div class="box">
				<div class="box-header">
					<h3 class="box-title">Data Table</h3>
				</div>
				<div class="box-body vendor-box">
					<table id="example1" class="table vendor-table table-striped">
						<thead class="vendor-head">
							<tr>
								<th>S.N.</th>
								<th>From</th>
								<th>To</th>
								<th>Date</th>
								<th>Shift</th>
								<th>Time</th>
								<th>Status</th>
                                <!-- <th>Action</th> -->
							</tr>
						</thead>
						<tbody>
						<?php ($i=1); ?>
                        <?php $__currentLoopData = $busroutines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        	<td><?php echo e($i++); ?></td>
				            <td><?php echo e($detail->from); ?></td>
				            
				            <td><?php echo e($detail->to); ?></td>
				            <td><?php echo e($detail->date); ?></td>
				            <td><?php echo e($detail->shift); ?></td>
				            <td><?php echo e(date("g:i a", strtotime($detail->time))); ?></td>
				            <!-- <td><?php echo e($detail->publish==1? 'active':'inactive'); ?></td> -->
				            <td>
				            	<?php
				            		$bookings=$detail->bookings;

				            	?>
				            	<?php if(count($bookings)==0): ?>
				            	<a class="btn vendor-busses btn-info edit" href="<?php echo e(route('editBusRoutine',$detail->id)); ?>" title="Edit">Edit</a>
								<?php endif; ?>
								<?php if(count($bookings)==0): ?>
				            	<a class="btn vendor-busses btn-danger" href="<?php echo e(route('deleteRoutine',$detail->id)); ?>" title="Edit" onclick="return confirm('Are you sure?')">Delete</a>
				            	<?php endif; ?>
				            	<a class="btn vendor-busses btn-warning" href="<?php echo e(route('smsView',$detail->id)); ?>" title="Edit" >SendSms</a>
				            	
               				   
				            </td>
				            
                        </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
  <!-- SlimScroll -->
  <script src="<?php echo e(asset('backend/plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
  <!-- FastClick -->
  <script src="<?php echo e(asset('backend/plugins/fastclick/fastclick.js')); ?>"></script>
  <script >
  	$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function(){
       $('.delete').submit(function(e){
        e.preventDefault();
        var message=confirm('Are you sure to delete');
        if(message){
          this.submit();
        }
        return;
       });
    });
  </script>
  <script>
  $(function () {
    $("#example1").DataTable();
  });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>