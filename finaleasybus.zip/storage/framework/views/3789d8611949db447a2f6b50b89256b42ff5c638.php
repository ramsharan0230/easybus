
<?php $__env->startSection('title','Online Booked Seat Report'); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>Booked Seat<small>report</small></h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"></i>Dashboard</a></li>
		<li><a href="">Report</a></li>
		<li><a href="">Vehicle</a></li>
	</ol>
</section>
<div class="content">
	<?php if(Session::has('message')): ?>
	<div class="alert alert-success alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
      		<span aria-hidden="true">&times;</span>
    	</button>
    	<?php echo Session::get('message'); ?>

	</div>
	<?php endif; ?>
	
	<div class="row">
		<div class="col-xs-12">
			<div class="box">
			    <div class="box-body">
			        <div class="row">
			            <div class="col-md-6">
			                <div class="form-group">
			                    <label class="font_13 m_b0">Travel Date</label>
			                    <input type="text" name="date" id="SelectDate" class="bod-picker form-control  border_radius0" autocomplete="off" value="">
			                </div>
			                <div class="form-group">
			                    <input type="submit" name="submit" class="btn btn-success datesubmit">
			                </div>
			            </div>
			            <div class="col-md-6">
			                <div class="form-group">
			                    <label class="font_13 m_b0">By Bus</label>
			                    <select class="form-control busData name="bus">
			                        <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                        <option value="<?php echo e($bus->id); ?>"><?php echo e($bus->bus_name); ?></option>
			                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                    </select>
			                    
			                </div>
			                <div class="form-group">
			                    <input type="submit" name="submit" class="btn btn-success searchbyBus">
			                </div>
			            </div>
			        </div>
			    </div>
			</div>
			<div class="box">
				<a href="<?php echo e(route('counterBookedSeats')); ?>" class="btn vendor-busses btn-success">Counter</a>
				<a href="<?php echo e(route('onlineBookedSeats')); ?>" class="btn vendor-busses btn-info">Online</a>
				<div class="box-header">
					<h3 class="box-title">Data Table</h3>
				</div>
				<div class="box-body vendor-box appendData">
					<table id="example1" class="table vendor-table table-striped">
						<thead class="vendor-head">
							<tr>
								<th>S.N.</th>
								<th>Booked By</th>
								<th>Bus</th>
								<th>From</th>
								<th>To</th>
								<th>Price</th>
								<th>Date</th>
								<th>Shift</th>
								<th>Booked On</th>
								
                                <!-- <th>Action</th> -->
							</tr>
						</thead>
						<tbody>
							<?php ($i=1); ?>
							<?php $__currentLoopData = $bookingReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($i); ?></td>
								<td>
									<?php echo e($report->name); ?><br>
									(<?php echo e($report->phone); ?>)
								</td>
								<td><?php echo e($report->bus->bus_name); ?>(<?php echo e($report->bus->bus_number); ?>)</td>
								<td><?php echo e($report->from); ?></td>
								<td><?php if($report->sub_destination): ?>
									<?php echo e($report->sub_destination); ?>

									<?php else: ?>
									<?php echo e($report->to); ?>

									<?php endif; ?>
								</td>
								<td><?php echo e($report->price); ?></td>
								<td><?php echo e($report->date); ?></td>
								<td><?php echo e($report->shift); ?></td>
								<td><?php echo e($report->booked_on); ?></td>

							</tr>
							<?php ($i++); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
  <!-- SlimScroll -->
  <script src="<?php echo e(asset('backend/plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
  <!-- FastClick -->
  <script src="<?php echo e(asset('backend/plugins/fastclick/fastclick.js')); ?>"></script>
  <script >
  	$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function(){
       $('.delete').submit(function(e){
        e.preventDefault();
        var message=confirm('Are you sure to delete');
        if(message){
          this.submit();
        }
        return;
       });
    });
  </script>
  <script>
  $(".bod-picker").nepaliDatePicker({
      dateFormat: "%y-%m-%d",
      closeOnDateSelect: true,
      // minDate: formatedNepaliDate
  });
  $(function () {
    $("#example1").DataTable({
    	"pageLength": 100
    });
  });

  $('.datesubmit').click(function(){
      if($('.bod-picker').val()==''){
          return;
      }else{
          date=$('.bod-picker').val();
          counter=0;
          online=1
          $.ajax({
              method:"post",
              url:"<?php echo e(route('searchPassengerByDate')); ?>",
              data:{date:date,counter:counter,online:online},
              success:function(data){
                  if(data.message){
                      $('#example1_wrapper').remove();
                      $('.appendData').append(data.html);
                      $("#example1").DataTable({
                          "pageLength": 100
                      });
                  }
              }
          });
      }
      
  });
  $('.searchbyBus').on('click',function(){

      busId=$('.busData').val();
      counter=1;
      $.ajax({
          method:"post",
          url:"<?php echo e(route('searchPassengerByBus')); ?>",
          data:{bus_id:busId,counter:counter},
          success:function(data){
              if(data.message){
                  $('#example1_wrapper').remove();
                  $('.appendData').append(data.html);
                  $("#example1").DataTable({
                      "pageLength": 100
                  });
              }
          }
      });
  });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>