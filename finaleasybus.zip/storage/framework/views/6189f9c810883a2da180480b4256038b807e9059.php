<?php $__env->startSection('title','All Counters'); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>All Counters<small>EASYBUS</small></h1>
                <ol class="breadcrumb">
                    <li><a href="./"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">Manage Counters</a></li>
                    <li class="active">All Counters</li>
                </ol>
            </section>
            
            <!-- Main content -->
            <section class="content">
                <div class="row equal_height">
                    <div class="col-lg-12">
                        <!-- Default box -->
                        <div class="box">

                           <!--  <div class="box-header">
                                <a href="#" class="btn btn-success">Add Counter</a>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                                    title="Collapse">
                                    <i class="fa fa-minus"></i></button>
                                </div>
                            </div> -->
                            <div class="box-body vendor-box">
                                <table id="example1" class="table vendor-table responsive table-hover dt-responsive nowrap bulk_action" >
                                    
                                    <thead class="vendor-head">
                                        <tr>
                                            <th>SN</th>
                                            <th>Counter Name</th>
                                            <!-- <th>Counter Assestant</th> -->
                                            <th><i class="fa fa-map-marker"></i> Location</th>
                                            <th><i class="fa fa-phone"></i> Telephone No.</th>
                                            
                                            <!-- <th><span class="fa fa-bus"></span> Approved Bus</th> -->
                                            <th> <i class="fa fa-at"></i> Email</th>
                                            <th>Action</th>

                                        </tr>
                                    </thead>
                                    <tbody class="text-uppercase">
                                        <?php ($i=1); ?>
                                        <?php $__currentLoopData = $counters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                                
                                            <td><?php echo e($i); ?>.</td>
                                            
                                            <td><?php echo e($counter->company_name); ?></td>
                                            <!-- <td> baburam thapa</td> -->
                                            <td><?php echo e($counter->address); ?></td>
                                            <td><?php echo e($counter->company_phone); ?></td>
                                            
                                            <!-- <td>
                                                <a href="approved-bus-list.php" class="btn btn-success"> <span class="fa fa-bus"></span> 3</a>
                                            </td> -->
                                            <td><?php echo e($counter->email); ?></td>
                                            
                                            <td>
                                                <a href="<?php echo e(route('vendors_counter_view',$counter->id)); ?>" class="btn vendor-busses"> <span class="fa fa-edit"></span> View</a>
                                                <a href="<?php echo e(route('ticketSale',$counter->id)); ?>" class="btn vendor-busses"> <span class="fa fa-edit"></span>Ticket Sale</a>
                                                <a href="<?php echo e(route('approvedBus',$counter->id)); ?>" class="btn vendor-busses"> <span class="fa fa-edit"></span>Approved Bus</a>
                                                <!-- <div class="btn  btn-danger">
                                                    <form method= "post" action="" class="delete">
                                                        <input type="hidden" name="_method" value="DELETE">
                                                        <button type="submit" class="btn-delete" style="display:inline"><span class="fa fa-trash"></span> Delete</button>
                                                    </form>
                                                </div> -->
                                            </td>
                                        </tr>
                                        <?php ($i++); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                    </tbody>
                                </table> 
                            </div>  
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </section>
            <!-- /.content -->
        
       

        

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
  <!-- SlimScroll -->
  <script src="<?php echo e(asset('backend/plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
  <!-- FastClick -->
  <script src="<?php echo e(asset('backend/plugins/fastclick/fastclick.js')); ?>"></script>
  <script >
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function(){
       $('.delete').submit(function(e){
        e.preventDefault();
        var message=confirm('Are you sure to delete');
        if(message){
          this.submit();
        }
        return;
       });
    });
  </script>
  <script>
  $(function () {
    $("#example1").DataTable({
        "pageLength":50
    });
  });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>