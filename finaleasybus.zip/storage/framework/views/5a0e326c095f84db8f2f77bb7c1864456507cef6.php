<?php $__env->startSection('content'); ?>
<section class="content">
 
	<div class=" p_tb40 user_dash">
		<div class="row">
			
			<div class="col-lg-12 col-md-12 col-12 ">
				<?php if(count($errors) > 0): ?>
				<div class="alert alert-danger message">
				    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				        <span aria-hidden="true">&times;</span>
				    </button>
				    <ul>
				        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <li><?php echo e($error); ?></li>
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    </ul>
				</div>
				<?php endif; ?>
					<?php if(Session::has('message')): ?>
					<div class="alert alert-success alert-dismissible">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				      		<span aria-hidden="true">&times;</span>
				    	</button>
				    	<?php echo Session::get('message'); ?>

					</div>
					<?php endif; ?>
				<div class="height_manage box_shadow search_back">
					<form action="<?php echo e(route('busSearchCounter')); ?>" method="get" class="form form-horizontal">
						<?php echo e(csrf_field()); ?>

						<div class="row form-group">
							<div class="col-lg-2 col-md-2">
								<label class="font_13 m_b0">From</label>

								<select name="from" class="form-control">
									<option value="">From</option>
									<?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($destination->name); ?>" <?php echo e($from==$destination->name?'selected':''); ?>><?php echo e($destination->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
					 
							<div class="col-lg-2 col-md-2">
								<label class="font_13 m_b0" >To</label>
								<select name="to" class="form-control">
									<option value="">To</option>
									<?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($destination->name); ?>" <?php echo e($to==$destination->name?'selected':''); ?>><?php echo e($destination->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
					 
							<div class="col-lg-2 col-md-2">
								<label class="font_13 m_b0">Travel Date</label>
						 
     
								<input type="text" name="date" id="SelectDate" class="bod-picker form-control  border_radius0" autocomplete="off" value="<?php echo e(Session::get('check_date')); ?>">
							 
							</div>
							<div class="col-lg-4 col-md-4">
								<label class="font_16">Shift</label>
								<ul class="take_shift shit_searh">
									<li>
										<ul class="shit_searh">
											<li>
										  		<input type="radio" name="shift" <?php echo e($shift=='Day'?'checked':''); ?> value="Day">
												
											</li>
											<li>
									    		<span class="input-group-text font_17" id="inputGroup-sizing-sm">Day</span>	
											</li>
										</ul>
									</li>
									<li>
										<ul class="shit_searh">
											<li>
										  		<input type="radio"  name="shift"  <?php echo e($shift=='Night'?'checked':''); ?> value="Night">
											</li>
											<li>
									    		<span class="input-group-text font_17" id="inputGroup-sizing-sm">Night</span>
											</li>
										</ul>
									</li>
									 
								</ul>
								  
							</div>
							<div class="col-lg-2 col-md-2">
								<button type="submit" class="btn btn-info search_button border_radius0"><i class="fa fa-search"></i> search</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 ">
				
				<div class="height_manage box_shadow">
					<div class="row">
					  	
					  	<div class="col-lg-12 col-md-12 col-12 text-capitalize ">
					  		<div class="row">
					  			<!-- <div class="col-lg-12 col-md-12 col-12 text-right p_tb40">
									<ul class="category_option">
										<?php $__currentLoopData = $busCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li>
											<button class="btn category_button category_active bus_category" data-id=<?php echo e($category->id); ?>><?php echo e($category->name); ?></button>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
									</ul>
								</div> -->
								<div class=" append">

									<div class="accordion" id="accordionExample">
										
										<?php $__currentLoopData = $busroutine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$routine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


										<?php
											$bus=$routine->bus;
											$facilities=explode(',',$bus->facilities);

										?>
  										<div class="card">
										    <div class="card-header" id="heading<?php echo e($routine->id); ?>">
										      	<h2 class="mb-0 m_tb0">
										        	<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($routine->id); ?>" aria-expanded="true" aria-controls="collapseOne">
										        		<div class="row">
										        			<div class="col-lg-2 col-md-2 col-12 text-left">
																<a href="<?php echo e(asset('images/main/'.$bus->image_1)); ?>">
																	<img src="<?php echo e(asset('images/main/'.$bus->image_1)); ?>" class="bus-image">
																</a>
										        				<span class="bus_name"> 
										          				<?php echo e($bus->bus_name); ?>

										          			</span>
										        			</div>
										        			<div class="col-lg-10 col-md-10">
												        		<ul class="main_info">
												          		 
												          			<li>
												          				<p><?php echo e($bus->bus_number); ?>  </p>
												          				<!-- <p>	4480</p> -->
												          			</li>
												          			<li>
												          				<p>time </p>
												          				<p>	<?php echo e($routine->time); ?></p>
												          			</li>
												          			<li>
												          				<p>price </p>
												          				<p>	Rs. <?php echo e($routine->price); ?></p>
												          			</li>
												          			<li>
												          				<p>bording point </p>
												          				<p> <?php echo e($bus->boarding_point); ?></p>
												          			</li>
												          			<li>
												          				<?php

												          				if($bus->busbBooking){
												          					$booked=count($bus->busBooking()->where('date',Session::get('check_date'))->get());
												          				}else{
												          					$booked=0;
												          				}
												          				if($bus->busseat){
												          					$available=count($bus->busseat)-$booked;
												          				}else{
												          					$available=0;
												          				}
												          				
												          				?>
												          				<p>available seat</p>
												          				<p> total : <?php echo e($available); ?></p>
												          			</li>
												          		</ul>
												          		<ul class="main_info m_t15 featuresList">
												          			<?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												          			<li>
												          				<p>	<?php echo e($facility); ?></p>
												          			</li>
												          			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												          			
												          		</ul>
										        			</div>
										        		</div>
										        	</button>

										      	</h2>
										    </div>
										    <div id="collapse<?php echo e($routine->id); ?>" class="collapse <?php echo e($key==0?'show':''); ?>" aria-labelledby="heading<?php echo e($routine->id); ?>" data-parent="#accordionExample">
										      	<div class="card-body">
										        	<div class="row ">
										        		<div class="col-lg-3 col-md-3  text-capitalize insideback">
										        			<p><?php echo e($bus->bus_number); ?></p>
										        		</div>
										        		<div class="col-lg-3 col-md-3  text-capitalize insideback">
										        			<p><?php echo e($routine->from); ?> to <?php echo e($routine->to); ?></p>
										        		</div>
										        		<div class="col-lg-3 col-md-3  text-capitalize insideback">
										        			<p><?php echo e(Session::get('check_date')); ?></p>
										        		</div>
										        		<div class="col-lg-3 col-md-3  text-capitalize insideback">
										        			
										        			<p><?php echo e($routine->shift); ?> shift</p>
										        			
										        		</div>
										        	</div>
										        	<ul class="checklist-wrapper main_info feature-color m_t15 featuresList">
										        		
										        		<?php $__currentLoopData = $routine->subDestinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sub_dest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										        		<li>
										        			<input type="radio" name="subdest" value="<?php echo e($sub_dest->id); ?>" class="sub_destination" data-id=<?php echo e($routine->id); ?>> <?php echo e($sub_dest->sub_destination); ?>

										        		</li>
										        		
										        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										        		
										        	</ul>
										        	<div class="row">
										        		<!-- <div class="col-lg-3 m_t15 p_lr0"> 
										        			<ul class="box_back p_tb15  text-capitalize bus_view_info no_liststyle">
										        				<p class="font_weight600 font_20 text-center"><?php echo e($bus->bus_name); ?></p>
										        				<li>
										        					<p>
										        						<small>Driver Name: </small>
										        						<?php if($bus->driver): ?>
										        						<?php echo e($bus->driver->name); ?>

										        						<?php endif; ?>
										        					</p> 
										        				</li>
										        				<li>
										        					<p>
										        						<small>
										        							assastent Name:
										        						</small>
										        						<?php if($bus->consuctor): ?>
										        						<?php echo e($bus->conductor->name); ?>

										        						<?php endif; ?>
										        					</p>
										        				</li>
										        				<li>
										        					<p>
										        						<small>
										        							contact no: 
										        						</small>

										        						<?php echo e($bus->assistant_two_phone); ?>

										        					</p>
										        				</li>
										        			</ul>
								        				 
								        				 
								        					<div class=" box_back   text-capitalize bus_view_info m_t10">
								        						<div class="facilities_title">
								        							<p class="font_weight600 font_20 text-center">facilities</p>
								        						</div>
								        						<div class="row m_lr0">

								        						<?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								        						<div class="col-lg-6 facility-detail p_lr10 font_17">
								        							<small><?php echo e($facility); ?> </small>
								        						</div>
								        						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								        							 
								        						</div>
								        						 
								        					</div>
								        					<div class=" box_back   text-capitalize bus_view_info m_t10">
								        						<div class="notice_title">
								        							<p class="font_weight600 font_20 text-center">notice</p>
								        						</div>
								        						<div class="notice-detail">
								        							<ul>
								        								<?php echo $bus->notice; ?>

								        							</ul>
								        						</div>
								        					</div>
										        		</div> -->
										        		<div class="col-lg-3 col-md-12  m_t15">
										        			<div class="row">
												        		<div class=" col-lg-4 col-md-4 col-sm-4 col-xs-4 mb-3 font_16 seat-text"> 
												        			<img src="<?php echo e(asset('front/assets/images/available-seat.png')); ?>" class="seat_icon2 ">  Available seat
												        		</div>
												        		<div class=" col-lg-4 col-md-4 col-sm-4 col-xs-4 mb-3 font_16 seat-text"> 
												        			<img src="<?php echo e(asset('front/assets/images/booked.png')); ?>" class="seat_icon2 "> Booked seat
												        		</div>
												        		<div class=" col-lg-4 col-md-4 col-sm-4 col-xs-4 mb-3 font_16 seat-text"> 
												        			<img src="<?php echo e(asset('front/assets/images/selected.png')); ?>" class="seat_icon2 "> selected seat
																</div>
																
										        			</div>
										        			<table class="counter_bus_seat_view">
					                                            <tbody >
					                                            	<?php for($i=0;$i<$bus->column;$i++): ?>
					                                                <tr>
					                                                	<?php for($j=0;$j<$bus->row;$j++): ?>
					                                                	<?php
					                                                	    $rowcol=$i.$j;
					                                                	    $busseat=$bus->busseat()->where('row_col',$rowcol)->first();
					                                                	    $check_date=Session::get('check_date');

					                                                	    $value=Session::get('jointable');

					                                                	    
					                                                	?>
					                                                    
					                                                    
					                                                    <td class="bookmyseat" data-id="<?php echo e($routine->id); ?>">
					                                                    	<?php if($i==0 && $j==$bus->row-1): ?>
					                                                        <img src="<?php echo e(asset('front/assets/images/stearing.png')); ?>" class="seat_icon2">
					                                                        <?php else: ?>
						                                                        <?php if($busseat): ?>
						                                                       		<?php if($busseat->booking()->where('bus_id',$bus->id)->where('date',$check_date)->where('from',$routine->from)->where('to',$routine->to)->first()): ?>
						                                                       			<div class="seat"></div>
                                                        						<img src="<?php echo e(asset('front/assets/images/booked.png')); ?>" class="seat_icon2 seat_change">
                                                        						<p class="booked_seat_text"><?php echo e($busseat->seat_name); ?></p>
						                                                       		<?php else: ?>
						                                                       			<div class="seat<?php echo e($routine->id); ?><?php echo e($i); ?><?php echo e($j); ?>"></div>
                                                        						<img src="<?php echo e(asset('front/assets/images/available-seat.png')); ?>" class="seat_icon2  seat_change" data-seat_no="<?php echo e($routine->id); ?><?php echo e($i); ?><?php echo e($j); ?>" data-seat_name="<?php echo e($busseat->seat_name); ?>" data-bus_id="<?php echo e($bus->id); ?>" data-price="<?php echo e($routine->price); ?>" data-si="<?php echo e($busseat->id); ?>">
                                                        						<p><?php echo e($busseat->seat_name); ?></p>
						                                                       		<?php endif; ?>
						                                                        
                                                    							<?php else: ?>
                                                    							<?php endif; ?>
                                                    						<?php endif; ?>

					                                                    </td>
					                                                    <?php endfor; ?>
					                                                </tr>
					                                                <?php endfor; ?>
					                                                
					                                            </tbody>
															</table>
															
															<div class="box_back p_a10 font_14 total-amount-wrapper booking_seat height_manage">
																<p>seat No.: 
																	<span class="choosen_seat<?php echo e($routine->id); ?>"></span>  
																</p>
																<p class="total_amount<?php echo e($routine->id); ?>">total amount:  </p>
																<div class="m_t10 text-right">
																	<a href="<?php echo e(route('counterbookNow',$routine->id)); ?>" class="btn btn-info btn-sm process" data-id="<?php echo e($routine->id); ?>">process</a>
																	
																</div>
															</div>
										        		</div>
										        		<div class="col-lg-9 m_t15">
										        			<!-- <div class="row equal_height">
										        				<div class="col-lg-12 col-md-12 col-12 p_lr5">
												        			<ul class="box_back p_tb15 bus_info_right ">
												        				<li>
												        					<p><?php echo e($routine->from); ?> to <?php echo e($routine->to); ?></p>
												        				</li>
												        				<li>
												        					<p><small>deaparture time </small><br>
												        						<?php echo e($routine->time); ?>

												        					</p>
												        				</li>
												        			</ul>
												        			<ul class="box_back p_tb15  text-capitalize bus_view_info">
												        				<li>
												        					<p>
												        						<small>bording point: </small>
												        						<?php echo e($bus->boarding_point); ?>

												        					</p> 
												        				</li>
												        			</ul>
												        			<ul class="box_back p_a15 bus_info_right">
												        				<li>
												        					<p><?php echo e($routine->shift); ?> shift</p>
												        				</li>
												        				<li>
												        					<p><small>price </small><br>
												        						rs. <?php echo e($routine->price); ?>

												        					</p>
												        				</li>
												        			</ul>
										        					
										        				</div>
										        				<div class="col-lg-5 col-md-6 col-12 m_t10 p_lr5">
										        					<div class="box_back p_a10 font_14 booking_seat height_manage">
											        					<p>seat No.: 
											        						<span class="choosen_seat<?php echo e($routine->id); ?>"></span>  
											        					</p>
										        						<p class="total_amount<?php echo e($routine->id); ?>">total amount:  </p>
											        					<div class="m_t10 text-right">
											        						<a href="<?php echo e(route('counterbookNow',$routine->id)); ?>" class="btn btn-info btn-sm process" data-id="<?php echo e($routine->id); ?>">process</a>
											        						
											        					</div>
										        					</div>
										        				</div>
										        				<div class="col-lg-7 col-md-6 col-12 m_t10 p_lr5">
										        					<div class="box_back p_a15 height_manage">
										        						<p>Ads here</p>
										        					</div>
										        				</div>
															</div> -->
															
															<!-- <ul class="driver-info">
																<li><p>Driver Number</p><span>9865802604</span></li>
																<li><p>Conductor Number</p><span>9865802604</span></li>
															</ul> -->
															<div class="row bus-image-row">
																<div class="col-lg-4 col-md-4 col-12">
																	<a href="<?php echo e(asset('images/main/'.$bus->image_1)); ?>" class="bus-image-wrapp">
																		<img src="<?php echo e(asset('images/main/'.$bus->image_1)); ?>">
																	</a>
																</div>
																<div class="col-lg-4 col-md-4 col-12">
																	<a href="<?php echo e(asset('images/main/'.$bus->image_2)); ?>" class="bus-image-wrapp">
																		<img src="<?php echo e(asset('images/main/'.$bus->image_2)); ?>">
																	</a>
																</div>
																<div class="col-lg-4 col-md-4 col-12">
																	<a href="<?php echo e(asset('images/main/'.$bus->image_3)); ?>" class="bus-image-wrapp">
																		<img src="<?php echo e(asset('images/main/'.$bus->image_3)); ?>">
																	</a>
																</div>
															</div>
															<div class="notice-wrapp">
																<h3>Notice Here</h3>
																<p><?php echo $routine->notice; ?></p>
															</div>
															<div class="row ad-section">
																<div class="col-lg-6 col-md-6 col-12">
																	<a href="<?php echo e(asset('front/images/ime-pay-300x150.webp')); ?>" class="ad-wrapper">
																		<img src="<?php echo e(asset('front/images/ime-pay-300x150.webp')); ?>">
																	</a>
																</div>
																<div class="col-lg-6 col-md-6 col-12">
																	<a href="<?php echo e(asset('front/images/300x250.gif')); ?>" class="ad-wrapper">
																		<img src="<?php echo e(asset('front/images/300x250.gif')); ?>">
																	</a>
																</div>
															</div>
										        		</div> 
										        	</div>
										      	</div>
										    </div>
  										</div> 
  										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>				
					  		</div>
					  	</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
 

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
	$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function(){
    $(".bod-picker").nepaliDatePicker({
    		dateFormat: "%y-%m-%d",
    		closeOnDateSelect: true,
    	// minDate: formatedNepaliDate
		});
    });
	$(document).ready(function(){
		var sub_price={};
		$(document).on('click','.sub_destination',function(){
			id=$(this).val();
			routine_id=$(this).data('id');
			$.ajax({
				method:'post',
				url:"<?php echo e(route('saveSubDestinationPrice')); ?>",
				data:{id:id,routine_id:routine_id},
				success:function(data){
					 console.log(data);
					if(data.status){
						sub_price={};
						sub_price[routine_id]=data.sub_destination_price;
					}else{
						window.location.href="<?php echo e(route('home')); ?>";
					}
				}
			});
		});
		$(document).on('click', '.bookmyseat', function(){

			id=$(this).data('id');
			seat_name=$(this).find('img').data('seat_name');
			image=$(this).find('img').attr('src');
			
			if(image=='<?php echo e(route("home")); ?>/front/assets/images/booked.png'){
				return;
			}
			seat_no=$(this).find('img').data('seat_no');
			check_value=$('#append_'+seat_no).val();
			if(check_value!=seat_no){
				seatname=[];
				sum=0;
				bus_id=$(this).find('img').data('bus_id');
				seat_id=$(this).find('img').data('si');
				
				price=$(this).find('img').data('price');
				Add='<input type="hidden" value="'+seat_no+'" id="append_'+seat_no+'" data-seat_name="'+seat_name+'" data-bus_id="'+bus_id+'" class="'+id+'" data-price="'+price+'">'
				$(this).find('.seat'+seat_no).append(Add);
				$(this).find('img').attr("src", "<?php echo e(route('home')); ?>/backend/assets/images/selected.png");
            	
				$.ajax({
					url: "<?php echo e(route('saveSession')); ?>",
       				method: 'post',
        			async: true,
        			data: { bus_id: bus_id,seat_id:seat_id,routine_id:id},
        			success:function(data){
        				
        				//console.log(data);
        				
        				if(data.status){
							$('.'+id).each(function(){
								price=$(this).data('price');
								// console.log(sub_price)
								if(sub_price){
									
									$.each(sub_price, function(key, value) {
									      key=key;
									      if(key==id){
									      	price=value;
									      }
									      
									});
									
								}
								// console.log(price);
								sum+=parseInt(price);

								if(sum!=0){
									$('#process'+id).addClass('process_background');
								}
								$('.total_amount'+id).html('');
								
								$('.total_amount'+id).append("total amount:"+sum);
			                	seatname.push($(this).data('seat_name'));
			            	});
			            	seatname.join(',');
			            	$('.choosen_seat'+id).html('');
			            	$(".choosen_seat"+id).append(seatname.toString());
        				}
        				
        			}
				});
            	
          
			}else{
				$(this).find('img').attr("src", "<?php echo e(route('home')); ?>/backend/assets/images/available-seat.png");
				bus_id=$(this).find('img').data('bus_id');
			    seat_id=$(this).find('img').data('si');
				$.ajax({
					url: "<?php echo e(route('removeSession')); ?>",
       				method: 'post',
        			async: true,
        			data: { bus_id: bus_id,seat_id:seat_id,routine_id:id},
        			success:function(data){
        				console.log(data);
        				if(data.status){
        					$('#append_'+seat_no).remove();
        					seatname = jQuery.grep(seatname, function(value) {
        					  return value != seat_name;
        					});
        					// alert(seatname);
        					$('.choosen_seat'+id).html('');
        					$(".choosen_seat"+id).append(seatname.toString());
        					price=data.price;
        					if(sub_price){
        						$.each(sub_price, function(key, value) {
        						      key=key;
        						      if(key==id){
        						      	price=value;
        						      }
        						});
        						
        					}
        					sum-=price;
    					    if(sum==0){
    					    	$('#process'+id).removeClass('process_background');
    					    }
    						$('.total_amount'+id).html('');
    						$('.total_amount'+id).append("total amount:"+sum);
        				}
        			}
				});
			}
			
		});
		

	});
	$(document).ready(function(){
		$(document).on('click','.process',function(e){
			e.preventDefault();
			id=$(this).data('id')
			// console.log(($('.'+id).length)
			if($('.'+id).length>0){
				seat_names=$('.choosen_seat').text();
				var url = '<?php echo e(route("counterbookNow", ":id")); ?>';

				url = url.replace(':id', id);

				window.location.href=url;
				

			}else{
				message=confirm('Please select seat');
				if(message){
					return ;
				}
			}
			
		});
	});
	$(document).ready(function(){
		$('.bus_category').click(function(){
			id=$(this).data('id');
			$.ajax({
				url: "<?php echo e(route('counterSelectBusByCategory')); ?>",
   				method: 'post',
    			async: true,
    			data: { id: id},
    			success:function(data){
    				console.log(data);
    				$('.accordion').remove();
    				 $('.append').html(data);
    				
    			}
			});
		});


		// $('button').click(function(e){
		// 	if (this.hasClass('collapsed')) {
		// 		var find_class = $(this).find('div.show');
		// 		if (find_class) {

		// 		}
		// 	}
		// })
	});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>