
<?php $__env->startSection('title','Destination List'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>All Destinations<small>EASYBUS</small></h1>
                <ol class="breadcrumb">
                    <li><a href="./"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">Destinations Management</a></li>
                    <li class="active">All Destinations</li>
                </ol>
            </section>
            
            <!-- Main content -->
            <section class="content">
                <div class="row equal_height">
                    <div class="col-lg-12">
                        <!-- Default box -->
                        <div class="box">

                            <div class="box-header">
                                <a href="<?php echo e(route('destination.create')); ?>" class="btn btn-success">Add New Destination</a>
                            </div>
                            <div class="box-body vendor-box">
                                <table id="example1" class="table vendor-table responsive table-hover dt-responsive nowrap bulk_action" >
                                    
                                    <thead class="vendor-head">
                                        <tr>
                                            <th>SN</th>
                                            <th>Name</th> 
                                            
                                             
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-uppercase">
                                        <?php ($i=1); ?>
                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?>.</td>
                                            <td><?php echo e($detail->name); ?></td>
                                            
                                            <td>
                                                <a href="<?php echo e(route('destination.edit',$detail->id)); ?>" class="btn vendor-busses"> <span class="fa fa-edit"></span> edit</a>
                                                <div class="btn vendor-busses">
                                                    <form method= "post" action="<?php echo e(route('destination.destroy',$detail->id)); ?>" class="delete">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <button type="submit" class="btn btn-delete" style="display:inline">Delete</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php ($i++); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table> 
                            </div>  
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </section>
            <!-- /.content -->
        
        
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    $(document).ready(function(){
       $('.delete').submit(function(e){
        e.preventDefault();
        var message=confirm('Are you sure to delete');
        if(message){
          this.submit();
        }
        return;
       });
       $("#example1").DataTable({
           "pageLength": 100
       });
    });
  </script>
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>