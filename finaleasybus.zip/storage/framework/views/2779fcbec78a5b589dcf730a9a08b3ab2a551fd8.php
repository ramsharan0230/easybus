<?php $__env->startSection('content'); ?>
<section class="">
	<div class="container p_tb40 user_dash">
		<div class="row">
			<div class="col-lg-4 offset-lg-4 col-md-12 col-12 ">
				<div class="height_manage box_shadow search_back">
						<?php if(count($errors) > 0): ?>
						<div class="alert alert-danger message">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					      		<span aria-hidden="true">&times;</span>
					    	</button>
							<ul>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
						<?php endif; ?>
					<form action="<?php echo e(route('counterseatBooking')); ?>" method="post" class="form form-horizontal">
						<?php echo e(csrf_field()); ?>

						<div class="row form-group ">
							<label class="col-lg-4 col-md-6 col-12 font_14">Full name :</label>
							<div class="col-lg-8 col-md-6 col-12">
								<input type="text" name="name" id="full_name" class="form-control form-control-sm rounded-0">
							</div>
						</div>

						<div class="row form-group ">
							<label class="col-lg-4 col-md-6 col-12 font_14">Contact No.:</label>
							<div class="col-lg-8 col-md-6 col-12">
								<input type="text" name="phone" id="phone" class="form-control form-control-sm rounded-0">
							</div>
						</div>
						<div class="row form-group ">
							<label class="col-lg-4 col-md-6 col-12 font_14">Date:</label>
							<div class="col-lg-8 col-md-6 col-12">
								<input type="text" name="date" id="phone" class="form-control form-control-sm rounded-0" value="<?php echo e(session()->get('check_date')); ?>" readonly="" >
							</div>
						</div>
						<div class="row form-group ">
							<label class="col-lg-4 col-md-6 col-12 font_14">Pickup station </label>
							<div class="col-lg-8 col-md-6 col-12">
								<input type="text" name="pickup_station" id="pickup" class="form-control form-control-sm rounded-0">
							</div>
						</div>
						<div class="row form-group ">
							<label class="col-lg-4 col-md-6 col-12 font_14">Drop station :</label>
							<div class="col-lg-8 col-md-6 col-12">
								<input type="text" name="drop_station" id="drop_station" class="form-control form-control-sm rounded-0">
							</div>
						</div>
						<div class="row form-group ">
							<label class="col-lg-4 col-md-6 col-12 font_14">Booking seats :</label>
							<div class="col-lg-8 col-md-6 col-12">
								<input type="text" name="seat_name" id="seats" readonly="" class="form-control form-control-sm rounded-0" value="<?php echo e($seatName); ?>">
							</div>
						</div>
						<div class="row form-group ">
							<label class="col-lg-4 col-md-6 col-12 font_14">Total Amount :</label>
							<div class="col-lg-8 col-md-6 col-12">
								<input type="text" name="price" id="price" class="form-control form-control-sm rounded-0" value="<?php echo e($total_price); ?>" readonly="">
							</div>
						</div>


						<div class="row form-group ">
							<label class="col-lg-4 col-md-6 col-12"></label>
							<div class="col-lg-8 col-md-6 col-12 text-center">
								<button type="submit"  class="btn btn-info">Make Payment</button>
							</div>
						</div>

						
					</form>
				</div>
			</div>
			 
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>