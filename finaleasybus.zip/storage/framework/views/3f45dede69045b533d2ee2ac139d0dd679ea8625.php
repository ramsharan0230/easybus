<?php if($buses!=null): ?>
<div class="accordion" id="accordionExample">
	<?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php
			$routine=$bus->busRoutine()->where('from',$from)->where('to',$to)->where('date',$date)->where('shift',$shift)->first();
			$facilities=explode(',',$bus->facilities);
		?>
	<div class="card">
	    <div class="card-header" id="heading<?php echo e($bus->id); ?>">
	      	<h2 class="mb-0">
	        	<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($bus->id); ?>" aria-expanded="true" aria-controls="collapseOne">
	        		<div class="row">
	        			<div class="col-lg-3 col-md-4 col-12 text-left">
							<div class="real-bus-wrapp">
								<a href="<?php echo e(asset('front/images/bus3.jpg')); ?>" class="real-bus">
									<img src="<?php echo e(asset('images/main/'.$bus->image_1)); ?>">
								</a>
								<span class="bus_name"> 
								<?php echo e($bus->bus_name); ?>

								<p><?php echo e($bus->bus_number); ?></p>
								</span>
							</div>
	        			</div>
	        			<div class="col-lg-9 col-md-8 col-12">
			        		<ul class="main_info">
			          		 
			          			<li>
			          				<p><?php echo e($bus->bus_number); ?>  </p>
			          				<!-- <p>	4480</p> -->
			          			</li>
			          			<li>
			          				<p>time </p>
			          				<p>	<?php echo e($routine->time); ?></p>
			          			</li>
			          			<li>
			          				<p>price </p>
			          				<p>	Rs. <?php echo e($routine->price); ?></p>
			          			</li>
			          			<li>
			          				<p>bording point </p>
			          				<p> <?php echo e($routine->boarding_point); ?></p>
			          			</li>
			          			<li>
			          				<?php
										$date=Session::get('check_date');
											
										$booked=count($bus->busBooking()->where('date',$date)->where('routine_id',$routine->id)->get());
										$available=count($bus->busseat)-$booked;
										?>
			          				<p>available seat</p>
			          				<p> total : <?php echo e($available); ?></p>
			          			</li>
			          		</ul>
			          		<ul class="main_info feature-color m_t15 featuresList">
			          			<?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			          			<li>
			          				<p>	<?php echo $facility; ?></p>
			          			</li>
			          			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          			
			          		</ul>
	        			</div>
	        		</div>
	        	</button>

	      	</h2>
	    </div>
	    <div id="collapse<?php echo e($bus->id); ?>" class="collapse <?php echo e($key==0?'show':''); ?>" aria-labelledby="heading<?php echo e($bus->id); ?>" data-parent="#accordionExample">
	      	<div class="card-body">
	        	<div class="row ">
	        		<div class="col-lg-3 col-md-3 col-12 text-capitalize insideback">
	        			<p><?php echo e($bus->bus_number); ?></p>
	        		</div>
	        		<div class="col-lg-3 col-md-3 col-12 text-capitalize insideback">
	        			<p><?php echo e($routine->from); ?> to <?php echo e($routine->to); ?></p>
	        		</div>
	        		<div class="col-lg-3 col-md-3 col-12 text-capitalize insideback">
	        			<p><?php echo e(Session::get('check_date')); ?></p>
	        		</div>
	        		<div class="col-lg-3 col-md-3 col-12 text-capitalize insideback">
	        			
	        			<p><?php echo e($routine->shift); ?> shift</p>
	        			
	        		</div>

	        	</div>
	        	<ul class="checklist-wrapper main_info feature-color m_t15 featuresList">
	        		<?php $__currentLoopData = $routine->subDestinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sub_dest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        		<li>
	        			<input type="radio" name="subdest" value="<?php echo e($sub_dest->id); ?>" class="sub_destination" data-id=<?php echo e($routine->id); ?>> <?php echo e($sub_dest->sub_destination); ?>

	        		</li>
	        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        	</ul>
	        	<div class="row margin-manager">
	        	
	        		<div class="col-lg-3 col-md-6 col-12 m_t15">
	        			<div class="row">
			        		<div class=" col-lg-4 col-md-4 col-4 mb-3 font_13"> 
			        			<img src="<?php echo e(asset('front/assets/images/available-seat.png')); ?>" class="seat_icon2">  Available seat
			        		</div>
			        		<div class=" col-lg-4 col-md-4 col-4 mb-3 font_13"> 
			        			<img src="<?php echo e(asset('front/assets/images/booked.png')); ?>" class="seat_icon2"> Booked seat
			        		</div>
			        		<div class=" col-lg-4 col-md-4 col-4 mb-3 font_13"> 
			        			<img src="<?php echo e(asset('front/assets/images/selected.png')); ?>" class="seat_icon2 "> selected seat
			        		</div>
	        				
	        			</div>
	        			<table class="counter_bus_seat_view">
                            <tbody >
                            	<?php for($i=0;$i<$bus->column;$i++): ?>
                                <tr>
                                	<?php for($j=0;$j<$bus->row;$j++): ?>
                                	<?php
                                	    $rowcol=$i.$j;
                                	    $busseat=$bus->busseat()->where('row_col',$rowcol)->first();
                                	    $check_date=Session::get('check_date');

                                	    $value=Session::get('jointable');

                                	    
                                	?>
                                    
                                    
                                    <td class="bookmyseat" data-id="<?php echo e($routine->id); ?>">
                                    	<?php if($i==0 && $j==$bus->row-1): ?>
                                        <img src="<?php echo e(asset('front/assets/images/stearing.png')); ?>" class="seat_icon2">
                                        <?php else: ?>
                                            <?php if($busseat): ?>
                                           		<?php if($busseat->booking()->where('bus_id',$bus->id)->where('date',$check_date)->where('from',$routine->from)->where('to',$routine->to)->where('routine_id',$routine->id)->first()): ?>
                                           			<div class="seat"></div>
                    						<img src="<?php echo e(asset('front/assets/images/booked.png')); ?>" class="seat_icon2 seat_change">
                    						<p class="booked_seat_text"><?php echo e($busseat->seat_name); ?></p>
                                           		<?php else: ?>
                                           			<div class="seat<?php echo e($routine->id); ?><?php echo e($i); ?><?php echo e($j); ?>"></div>
                    						<img src="<?php echo e(asset('front/assets/images/available-seat.png')); ?>" class="seat_icon2 seat_change" data-seat_no="<?php echo e($routine->id); ?><?php echo e($i); ?><?php echo e($j); ?>" data-seat_name="<?php echo e($busseat->seat_name); ?>" data-bus_id="<?php echo e($bus->id); ?>" data-price="<?php echo e($routine->price); ?>" data-si="<?php echo e($busseat->id); ?>">
                    						<p><?php echo e($busseat->seat_name); ?></p>
                                           		<?php endif; ?>
                                            
                							<?php else: ?>
                							<?php endif; ?>
                						<?php endif; ?>

                                    </td>
                                    <?php endfor; ?>
                                </tr>
                                <?php endfor; ?>
                                
                            </tbody>
						</table>
							<div class="box_back p_a10 font_14 booking_seat seat-detail-wrapper">
	        					<p>seat No.: 
	        						<span class="choosen_seat<?php echo e($routine->id); ?>">
	        							
	        						</span>  
	        					</p>
	        					<p class="total_amount<?php echo e($routine->id); ?>">total amount:  </p>
	        					<div class="m_t10 text-right">
	        						<a href="<?php echo e(route('bookNow',$routine->id)); ?>" class="btn btn-info btn-sm process" data-id="<?php echo e($routine->id); ?>">process</a>
	        						
	        					</div>
							</div>
	        		</div>
	        		<div class="col-lg-9 col-md-12 m_t15">
	        			
						<div class="new-layout">
							<!-- <ul class="driver-info-wrapp">
								<li><p>Driver Number</p><span>9865802604</span></li>
								<li><p>Conductor Number</p><span>9865802604</span></li>
							</ul> -->
							<div class="row bus-image-row">
								<div class="col-lg-4 col-md-4 col-12">
									<a href="<?php echo e(asset('images/main/'.$bus->image_1)); ?>" class="bus-image-wrapp">
										<img src="<?php echo e(asset('images/main/'.$bus->image_1)); ?>">
									</a>
								</div>
								<div class="col-lg-4 col-md-4 col-12">
									<a href="<?php echo e(asset('images/main/'.$bus->image_2)); ?>" class="bus-image-wrapp">
										<img src="<?php echo e(asset('images/main/'.$bus->image_2)); ?>">
									</a>
								</div>
								<div class="col-lg-4 col-md-4 col-12">
									<a href="<?php echo e(asset('images/main/'.$bus->image_3)); ?>" class="bus-image-wrapp">
										<img src="<?php echo e(asset('images/main/'.$bus->image_3)); ?>">
									</a>
								</div>
							</div>
							<div class="notice-wrapp">
								<h3>Notice Here</h3>
								<p><?php echo $routine->notice; ?></p>
							</div>
							<div class="row ad-section">
								<div class="col-lg-6 col-md-6 col-12">
									<a href="<?php echo e(asset('front/images/ime-pay-300x150.webp')); ?>" class="ad-wrapper">
										<img src="<?php echo e(asset('front/images/ime-pay-300x150.webp')); ?>">
									</a>
								</div>
								<div class="col-lg-6 col-md-6 col-12">
									<a href="<?php echo e(asset('front/images/bus3.jpg')); ?>" class="ad-wrapper">
										<img src="<?php echo e(asset('front/images/300x250.gif')); ?>">
									</a>
								</div>
							</div>
						</div>
	        		</div> 
	        	</div>
	      	</div>
	    </div>
		</div> 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>