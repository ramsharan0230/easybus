
<?php $__env->startSection('content'); ?>

<style>
	thead {
    color: #fff;
    background: #132634;
	}
</style>
<section class="">
	<div class="container user_dash">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 ">
				<div class="height_manage user-dash-page box_shadow">
					<div class="row">
					  	<div class="col-lg-2 col-sm-12">
						   <?php echo $__env->make('front.include.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					  	</div>
					  	<div class="col-lg-10 col-sm-12 text-capitalize">
							<div class="padding-manager">
								<div class="row">
									
									<div class="col-lg-12   col-sm-12 ">
										<table class="table table-bordered  text-uppercase font_13" width="100%">
											<thead>
												<tr>
													<th>Sn.</th>
													<th>Bus No</th>
													<th>sit no</th>
													<th> Destination</th>
													<th>booked on</th>
													<th>departure date</th>
													<th>rate</th>
													<!-- <th> total amount</th>
													<th> payment status</th> -->
												</tr>
											</thead>
											<tbody>
												<?php ($i=1); ?>
												<?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr class='clickable-row' data-href='https://www.facebook.com/'>
													
													<td><?php echo e($i); ?></td>
													<td><?php echo e($detail->bus->bus_number); ?></td>
													<td> <?php echo e($detail->seat->seat_name); ?></td>
													<td>
														<small>
															from: <?php echo e($detail->from); ?>

														</small>
														<br>
														<?php if($detail->sub_destination): ?>
															<small>to: <?php echo e($detail->sub_destination); ?></small>
														<?php else: ?>
															<small>to: <?php echo e($detail->to); ?></small>
														<?php endif; ?>
														
													</td>
													<td><?php echo e($detail->booked_on); ?></td>
													<td>
														<?php echo e($detail->date); ?> <br>
														<small><?php echo e(date("g:i a", strtotime($detail->time))); ?></small>
													</td>
													<td>
														<span>Rs.</span> <?php echo e($detail->price); ?> /-
													</td>
													
												</tr>	
												<?php ($i++); ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
											</tbody>
										</table>
										<div class="col-lg-12 col-sm-12">
											<div class="row">
												<div class="col-lg-8 col-sm-12">
													<ul class="font_14">
														<li>
															- Your all ticketing history will be listed here.
														</li>
														<li>
															- All points you earned will be displayed here.
														</li>
														<!-- <li>
															- After tickets of Rs. 10,000/- you will earn 1 points.
														</li> -->
													</ul>
												</div>
												<div class="col-lg-4 col-sm-12 font_14">
													<ul>
														<li>
															<span class=" font_weight600">Total Money spent:</span> <?php echo e($details->sum('price')); ?> /-
														</li>
														<li>
															<span class=" font_weight600"> Tickets:</span> <?php echo e(count($details)); ?>

														</li>
														<!-- <li>
															<span class=" font_weight600"> Earned Point:</span> 1234
														</li>
														<li>
															<span class=" font_weight600"> spent points:</span> 123
														</li>
														<li>
															<span class=" font_weight600"> remaining points:</span> 923
														</li> -->
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
					  	</div>
					</div>
				</div>
			</div>
			 
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>