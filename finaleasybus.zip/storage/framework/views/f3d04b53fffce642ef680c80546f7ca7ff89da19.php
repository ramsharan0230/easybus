
<?php $__env->startSection('title','Bus List'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1><?php echo e($category->name); ?> Bus<small>List</small></h1>
    <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li><a href=""><?php echo e($category->name); ?> Bus</a></li>
        <li><a href="">list</a></li>
    </ol>
</section>
<div class="content">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <?php echo Session::get('message'); ?>

    </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Data Table(total number of buses = <?php echo e(count($details)); ?>)</h3>
                </div>
                <div class="box-body vendor-box">
                    <table id="example1" class="table vendor-table table-striped">
                        <thead class="vendor-head">
                            <tr>
                                <th>S.N.</th>
                                <th>Bus No</th>
                                <th>Bus Name</th>
                                <th>Status</th>
                                <th>Bus Layout</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($detail->bus_number); ?></td>
                            <!-- <td><?php if($detail->image): ?>
                                <img src="<?php echo e(asset('images/listing/'.$detail->image)); ?>">
                                <?php else: ?>
                                <p>N/A</p>
                                <?php endif; ?>
                            </td> -->

                            <td><?php echo e($detail->bus_name); ?></td>
                            <td><?php echo e($detail->status); ?></td>
                            <!-- <td><?php echo e($detail->publish==1? 'active':'inactive'); ?></td> -->
                            <td>
                                <a class="btn vendor-busses edit" href="<?php echo e(route('busDetail',$detail->id)); ?>" title="Edit">Bus Layout</a>
                                
                                
                            </td>
                            
                        </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
  <script >
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function(){
       $('.delete').submit(function(e){
        e.preventDefault();
        var message=confirm('Are you sure to delete');
        if(message){
          this.submit();
        }
        return;
       });
    });
  </script>
  <script>
  $(function () {
    $("#example1").DataTable({
        "pageLength":50
    });
  });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>