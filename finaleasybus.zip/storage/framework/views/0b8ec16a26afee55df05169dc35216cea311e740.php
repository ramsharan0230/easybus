<table id="example1" class="table vendor-table table-striped">
                        <thead class="vendor-head">
                            <tr>
                                <th>S.N.</th>
                                <th>Booked By</th>
                                <th>Bus</th>
                                <th>From</th>
                                <th>To</th>
                                <?php if($counter==1): ?>
                                <th>Counter</th>
                                <?php endif; ?>
                                <th>Price</th>
                                <th>Date</th>
                                <th>Shift</th>
                                <th>Booked On</th>
                                
                                <!-- <th>Action</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $bookingReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td>
                                    <?php echo e($report->name); ?><br>
                                    (<?php echo e($report->phone); ?>)
                                </td>
                                <td><?php echo e($report->bus->bus_name); ?>(<?php echo e($report->bus->bus_number); ?>)</td>
                                <td><?php echo e($report->from); ?></td>
                                <td><?php if($report->sub_destination): ?>
                                    <?php echo e($report->sub_destination); ?>

                                    <?php else: ?>
                                    <?php echo e($report->to); ?>

                                    <?php endif; ?>
                                </td>
                                <?php if($counter==1): ?>
                                <td><?php echo e($report->counter->name); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($report->price); ?></td>
                                <td><?php echo e($report->date); ?></td>
                                <td><?php echo e($report->shift); ?></td>
                                <td><?php echo e($report->booked_on); ?></td>

                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>