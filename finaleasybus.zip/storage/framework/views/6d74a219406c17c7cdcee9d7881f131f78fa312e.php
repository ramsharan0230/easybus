
<?php $__env->startSection('title','Pending Counter'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>All Pending Counters<small>EASYBUS</small></h1>
                <ol class="breadcrumb">
                    <li><a href="./"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">User Management</a></li>
                    <li><a href="#">Counter Management</a></li>
                    <li class="active">All Counter Counters</li>
                </ol>
            </section>
            
            <!-- Main content -->
            <section class="content">

                <div class="row equal_height">
                    <div class="col-lg-12">
                        <!-- Default box -->
                        <div class="box">

                            <div class="box-header">
                                <!-- <a href="vendor-list.php" class="btn btn-success">All Vendor</a> -->
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                                    title="Collapse">
                                    <i class="fa fa-minus"></i></button>
                                </div>
                            </div>
                            <div class="box-body vendor-box">
                                <table id="example1" class="table vendor-table responsive table-hover dt-responsive nowrap bulk_action" >
                                    
                                    <thead class="vendor-head">
                                        <tr>
                                            <th>SN</th>
                                            <th>Company Name</th>
                                            <th>Role</th>
                                            <th><i class="fa fa-phone"></i> Contact No.</th>
                                            <th> <i class="fa fa-at"></i> Email</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php ($i=1); ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?>.</td>
                                            <td><?php echo e($user->company_name); ?></td>
                                            <td>Vendor</td>
                                            <td><?php echo e($user->company_phone); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            
                                            <td>
                                                <!-- <a href="vendor-detail.php" class="btn btn-info"> <span class="fa fa-eye"></span> View</a> -->
                                                 
                                                <div class="btn  vendor-busses">
                                                   
                                                    <form method= "post" action="<?php echo e(route('approveVendorRequest')); ?>" class="delete">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                                    
                                                        <button type="submit" class="btn-delete " style="display:inline" ><span class="fa fa-check"></span> Approve</button>
                                                    </form>

                                                   
                                                </div>
                                                <a href="<?php echo e(route('vendor.show',$user->id)); ?>" class="btn vendor-busses">View</a>

                                                
                                            </td>
                                        </tr>
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                       
                                    </tbody>
                                </table> 
                            </div>
                        </div>
                        <!-- /.box -->
                    </div>
                </div>


                

            </section>
            <!-- /.content -->
        

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
  
<script >
    $(document).ready(function(){
       
    });
    $(function () {
    $("#example1").DataTable({
        "pageLength": 100
    });
  });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>