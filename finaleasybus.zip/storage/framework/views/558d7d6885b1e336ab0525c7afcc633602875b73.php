
<?php $__env->startSection('title','Vendor Booked Seat Report'); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>Booked Seat<small>report</small></h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"></i>Dashboard</a></li>
		<li><a href="">Report</a></li>
		<li><a href="">Vehicle</a></li>
	</ol>
</section>
<div class="content">
	<?php if(Session::has('message')): ?>
	<div class="alert alert-success alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
      		<span aria-hidden="true">&times;</span>
    	</button>
    	<?php echo Session::get('message'); ?>

	</div>
	<?php endif; ?>
	
	<div class="row">
		<div class="col-xs-12">
			
			<div class="box">
				<a href="" class="btn vendor-busses btn-success counter" data-vendor_id="<?php echo e($details->id); ?>">Counter</a>
				<a href="" class="btn vendor-busses btn-info online" data-vendor_id="<?php echo e($details->id); ?>">Online</a>
				<div class="box-header">
					<h3 class="box-title">Data Table</h3>
				</div>
				<div class="box-body appendData">
					<table id="example1" class="vendor-table table table-striped">
						<thead class="vendor-head">
							<tr>
								<th>S.N.</th>
								<th>Booked By</th>
								<th>Bus</th>
								<th>From</th>
								<th>To</th>
								<th>Price</th>
								<th>Date</th>
								<th>Shift</th>
								<th>Booked On</th>
								
                                <!-- <th>Action</th> -->
							</tr>
						</thead>
						<tbody>
							<?php ($i=1); ?>
							<?php $__currentLoopData = $details->vendor_bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($i); ?></td>
								<td>
									<?php echo e($report->name); ?><br>
									(<?php echo e($report->phone); ?>)
								</td>
								<td><?php echo e($report->bus->bus_name); ?>(<?php echo e($report->bus->bus_number); ?>)</td>
								<td><?php echo e($report->from); ?></td>
								<td><?php if($report->sub_destination): ?>
									<?php echo e($report->sub_destination); ?>

									<?php else: ?>
									<?php echo e($report->to); ?>

									<?php endif; ?>
								</td>
								<td><?php echo e($report->price); ?></td>
								<td><?php echo e($report->date); ?></td>
								<td><?php echo e($report->shift); ?></td>
								<td><?php echo e($report->booked_on); ?></td>

							</tr>
							<?php ($i++); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
  <!-- SlimScroll -->
  <script src="<?php echo e(asset('backend/plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
  <!-- FastClick -->
  <script src="<?php echo e(asset('backend/plugins/fastclick/fastclick.js')); ?>"></script>
  <script >
  	$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function(){
       $('.delete').submit(function(e){
        e.preventDefault();
        var message=confirm('Are you sure to delete');
        if(message){
          this.submit();
        }
        return;
       });
    });
  </script>
  <script>
  $(".bod-picker").nepaliDatePicker({
      dateFormat: "%y-%m-%d",
      closeOnDateSelect: true,
      // minDate: formatedNepaliDate
  });
  $(function () {
    $("#example1").DataTable({
    	"pageLength": 100

    });
  });

  $('.online').click(function(e){
  	e.preventDefault();
  	vendor_id=$(this).data('vendor_id');
  	online=1;
  	counter=0;
  	$.ajax({
  		method:"post",
  		url:"<?php echo e(route('vendorOnlineTicket')); ?>",
  		data:{vendor_id:vendor_id,online:online,counter:counter},
  		success:function(data){
  			if(data.message){
              $('#example1_wrapper').remove();
              $('.appendData').append(data.html);
              $("#example1").DataTable({
                  "pageLength": 100
              });
          }
  		}
  	});
  	
  });
  $('.counter').click(function(e){
  		e.preventDefault();
  		
  		vendor_id=$(this).data('vendor_id');
  		online=0;
  		counter=1;
  		$.ajax({
  			method:"post",
  			url:"<?php echo e(route('vendorOnlineTicket')); ?>",
  			data:{vendor_id:vendor_id,online:online,counter:counter},
  			success:function(data){
  				console.log(data);
  				if(data.message){
  	            $('#example1_wrapper').remove();
  	            $('.appendData').append(data.html);
  	            $("#example1").DataTable({
  	                "pageLength": 100
  	            });
  	        }
  			}
  		});
  })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>